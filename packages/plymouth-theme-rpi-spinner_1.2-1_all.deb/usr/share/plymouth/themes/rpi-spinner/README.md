##<font color="#55aa00"><b>DEEPIN-15-LOGINSPINNER-DEBIAN-LOGO-BLACK-BGRD</b></font>

* __`Version:`__ 1.0
* __`Date:`__ 06.01.2022
* __`License:`__  [GPL-3.0](https://www.gnu.org/licenses/gpl-3.0.txt)
* __`Author:`__ [DUKE93](https://www.pling.com/u/Duke93)

---------------------------------

* This theme is based on: __breeze-plymouth__ --> <https://github.com/KDE/breeze-plymouth/tree/master/breeze>.
* The resource for the spinner was the file `/usr/share/icons/deepin/cursors/loginspinner` from the Deepin 15 distribution.

---------------------------------
### Changelog:
>
___`v1.0 (06.01.2022)`___
>
* `First release`









